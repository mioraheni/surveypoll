//
//  ViewController.swift
//  TestURL
//
//  Created by admin on 08/12/2017.
//  Copyright © 2017 admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let database = loadData()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadData() -> TopFreeBooks{
        //https://rss.itunes.apple.com/api/v1/fr/books/top-free/all/10/explicit.json
        
        var database = TopFreeBooks()
        
       
        if let url = URL(string: "https://rss.itunes.apple.com/api/v1/fr/books/top-free/all/10/explicit.json"){
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                // telechargement OK/FAIL ici
                guard let data = data , error == nil else{
                    print("ERROR")
                    return
                }
                do{
                    let root = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.allowFragments)
                    if let rootDict = root as? [String : Any]{
                        if let feed = rootDict["feed"] as? [String : Any]{
                            if let title = feed["title"] as? String,
                                let id = feed["id"] as? String,
                                let copyright = feed["copyright"] as? String,
                                let country = feed["country"] as? String,
                                let icon = feed["icon"] as? String,
                                let updated = feed["updated"] as? String{
                                
                                    database.title = title
                                    
//                                    print("titre : \(title)")
//                                    print("id : \(id)")
                                    if let idDB = Int(id){
                                        database.id = idDB
                                    }
                                
                                    if let author = feed["author"] as? [String : Any]{
                                        var auteur = Author()
                                        if let authorName = author["name"] as? String{
                                            auteur.authorName = authorName
//                                            print("name : \(authorName)")
                                        }
                                        if let authorUri = author["uri"] as? String{
                                            auteur.authorUri = authorUri
//                                            print("uri : \(authorUri)")
                                        }
                                        auteur.toString()
                                        database.authors.append(auteur)
                                    }
                                
                                    if let links = feed["links"] as? [ [String : Any] ]{
                                        var lien = Link()
                                        for link in links{
                                            if let salf = link["self"] as? String{
//                                                print("self : \(salf)")
                                                lien.salf = salf
                                            }
                                            if let alternate = link["alternate"] as? String{
//                                                print("alternate : \(alternate)")
                                                lien.alternate = alternate
                                            }
                                        }
                                        lien.toString()
                                    }
                                    //print("copyright : \(copyright)")
                                    database.copyright = copyright
//                                    print("country : \(country)")
                                    database.country = country
//                                    print("icon : \(icon)")
                                    database.icon = icon
//                                    print("updated : \(updated)")
                                
//                                    Impossible de transformer en format date donc laisser en string
//                                    let dateFormatter = DateFormatter()
//                                    database.updated = dateFormatter.date(from: updated)
                                    database.updated = updated
                            }
                            if let results = feed["results"] as? [ [String : Any] ]{
                                for result in results{
                                    var book = Book()
                                    
                                    if let artistName = result["artistName"] as? String,
                                        let resultId = result["id"] as? String,
                                        let releaseDate = result["releaseDate"] as? String,
                                        let bookName = result["name"] as? String,
                                        let kind = result["kind"] as? String,
                                        let artistId = result["artistId"] as? String,
                                        let artistUrl = result ["artistUrl"] as? String,
                                        let artworkUrl100 = result["artworkUrl100"] as? String,
                                        let resultUrl = result["url"] as? String{
                                        
                                            if let idResult = Int(resultId), let idArtist = Int(artistId){
                                                book.id = idResult
                                                book.artistId = idArtist
                                            }
//                                            Impossible de transformer en format date donc laisser en string
//                                            let dateFormatter = DateFormatter()
//                                            book.releaseDate = dateFormatter.date(from: releaseDate)
                                            book.releaseDate = releaseDate
//                                            print("Artiste : \(artistName)")
                                            book.artistName = artistName
                                            //print("resultId : \(resultId)")
                                            //print("releaseDate : \(releaseDate)")
                                            //print("name : \(bookName)")
                                            book.name = bookName
                                            //print("kind : \(kind)")
                                            //print("artistId : \(artistId)")
                                            //print("artistUrl : \(artistUrl)")
                                            book.artistUrl = artistUrl
                                            //print("Artwork : \(artworkUrl100)")
                                            book.url100 = artworkUrl100
                                            if let genres = result["genres"] as? [ [String : Any] ]{
                                                for genre in genres{
                                                    var genreObject = Genre()
                                                    
                                                    if let genreID = genre["genreId"] as? String,
                                                        let genreName = genre["name"] as? String,
                                                        let genreUrl = genre["url"] as? String{
                                                            genreObject.name = genreName
                                                            genreObject.url = genreUrl

                                                            if let idNum = Int(genreID){
                                                                genreObject.id = idNum
                                                            }
                                                            //print("genreId : \(genreID)")
                                                            //print("genreName : \(genreName)")
                                                            //print("genreUrl : \(genreUrl)")
                                                    }
                                                    genreObject.toString()
                                                    book.genres.append(genreObject)
                                                }
                                            }
//                                            print("URL : \(resultUrl)")
                                            book.url = resultUrl
                                    }
                                    book.toString()
                                    database.books.append(book)
                                    database.toString()
                                    
                                }
                            }
                        }
                    }
                    print("JSON OK")
                }catch{
                    //[String : Any]
                }
                print("Did Download")
            }).resume()
        }
        print("Start Download")
        
        return database
    }


}

