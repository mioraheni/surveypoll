//
//  ViewController.swift
//  surveypoll
//
//  Created by Henintsoa Miora on 08/03/2018.
//  Copyright © 2018 Hauret Xiong. All rights reserved.
//

import UIKit

class LoginController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
//        @IBOutlet UILabel
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

 
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool
    {
        if (identifier == "connexion"){
            return true
        }else{
            return true
        }
        
    }
    /*
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
     
     
        var controller = segue.destination as! MyViewController
        controller.user =
    }
 */

}

